package com.example.loginapp;

public interface AuthenticationListener {

    void onTokenReceived(String auth_token);
}
