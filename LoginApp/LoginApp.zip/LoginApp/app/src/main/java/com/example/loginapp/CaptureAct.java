package com.example.loginapp;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureAct extends CaptureActivity
{


}
