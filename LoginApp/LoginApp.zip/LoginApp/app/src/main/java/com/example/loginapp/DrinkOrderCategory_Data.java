package com.example.loginapp;

public class DrinkOrderCategory_Data {


    String subCategoryName;
    String subCategoryDescription;
    String price;
    String productid;

    boolean isfourite;

    public DrinkOrderCategory_Data(String subCategoryName, String subCategoryDescription, String price,String productid) {
        this.subCategoryName = subCategoryName;
        this.subCategoryDescription = subCategoryDescription;
        this.price = price;
        this.productid = productid;
    }
}
