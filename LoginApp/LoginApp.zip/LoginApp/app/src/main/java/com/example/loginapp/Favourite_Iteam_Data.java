package com.example.loginapp;

public class Favourite_Iteam_Data {

    String productId;
    String productName;

    public Favourite_Iteam_Data(String productId , String productName) {
        this.productId = productId;
        this.productName = productName;

    }
}
