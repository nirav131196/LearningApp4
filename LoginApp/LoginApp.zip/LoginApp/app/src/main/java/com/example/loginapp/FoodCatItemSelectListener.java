package com.example.loginapp;

public interface FoodCatItemSelectListener {

    void OnItemClicked(FoodProductData data);
}
