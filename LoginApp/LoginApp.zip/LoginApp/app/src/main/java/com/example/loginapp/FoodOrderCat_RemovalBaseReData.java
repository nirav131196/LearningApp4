package com.example.loginapp;

import com.google.gson.annotations.SerializedName;

public class FoodOrderCat_RemovalBaseReData {

    String status;
    String message;
}
