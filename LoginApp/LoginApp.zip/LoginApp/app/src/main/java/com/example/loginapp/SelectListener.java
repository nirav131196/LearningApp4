package com.example.loginapp;

public interface SelectListener {

    void OnItemClicked(Product_Data data);
}
