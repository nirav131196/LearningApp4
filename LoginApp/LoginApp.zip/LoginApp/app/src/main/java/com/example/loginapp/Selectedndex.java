package com.example.loginapp;

public interface Selectedndex {

    void setSelectedIndex(int position);
}
